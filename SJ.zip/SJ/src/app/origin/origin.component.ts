import { Component } from '@angular/core';

@Component({
    selector: 'app-origin',
    templateUrl: './origin.component.html',
    styleUrls: ['./origin.component.css']
})
export class OriginComponent {
    title = 'task';
}
