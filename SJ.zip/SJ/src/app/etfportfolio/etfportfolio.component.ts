import { Component } from '@angular/core';
@Component({
  selector:'app-etfportfolio',
  templateUrl:'./etfportfolio.component.html',
  styleUrls:['./etfportfolio.component.css']
})
export class EtfportfolioComponent {
  

}
