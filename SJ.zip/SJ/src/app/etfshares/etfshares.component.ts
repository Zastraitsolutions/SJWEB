import { Component } from '@angular/core';
@Component({
  selector:'app-etfshares',
  templateUrl:'./etfshares.component.html',
  styleUrls:['./etfshares.component.css']
})
export class EtfSharesComponent {
  

}

