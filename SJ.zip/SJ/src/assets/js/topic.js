$(document).ready(function(){
  $("#topic").click(function(){
    $("#panel").slideToggle("slow");
  });
});